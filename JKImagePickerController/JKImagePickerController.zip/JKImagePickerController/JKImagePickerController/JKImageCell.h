//
//  JKImageCell.h
//  JKImagePickerController
//
//  Created by zjk on 2017/2/23.
//  Copyright © 2017年 zhuJiKai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKImageCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imageView;

@end
