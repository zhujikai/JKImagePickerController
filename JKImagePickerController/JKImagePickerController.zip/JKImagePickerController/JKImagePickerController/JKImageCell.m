//
//  JKImageCell.m
//  JKImagePickerController
//
//  Created by zjk on 2017/2/23.
//  Copyright © 2017年 zhuJiKai. All rights reserved.
//

#import "JKImageCell.h"

@implementation JKImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
